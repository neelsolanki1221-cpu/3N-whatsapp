// api/send-whatsapp.js
//
// This is the ONE piece a static website can never do safely on its own:
// holding API credentials and calling WhatsApp's Business API. It has to
// live on a real server. This file IS that server — a single serverless
// function you deploy for free on Vercel.
//
// WHAT IT DOES
// The 3N Electronics site calls this endpoint automatically the instant an
// order is placed (see "Automated WhatsApp invoice" in Settings). This
// function then:
//   1. Sends a WhatsApp message to the customer with their order summary
//   2. Sends a WhatsApp message to your team's number(s) with the same
//
// SETUP (about 15–20 minutes, free to start)
//   1. Create a Twilio account: https://www.twilio.com/try-twilio
//   2. In the Twilio Console, open "Messaging" -> "Try it out" ->
//      "Send a WhatsApp message" to activate the WhatsApp Sandbox.
//      (For production/non-sandbox sending to any number without them
//      opting in first, you'll need to apply for a WhatsApp Business
//      sender — Twilio walks you through this from the same page.)
//   3. Note down from the Twilio Console:
//        - Account SID
//        - Auth Token
//        - Your Twilio WhatsApp number (looks like "whatsapp:+14155238886")
//   4. Deploy this folder to Vercel (see README.md in this folder for the
//      exact steps) and set these as Environment Variables in the Vercel
//      project settings:
//        TWILIO_ACCOUNT_SID
//        TWILIO_AUTH_TOKEN
//        TWILIO_WHATSAPP_FROM       e.g. whatsapp:+14155238886
//        TEAM_WHATSAPP_NUMBERS      comma-separated, e.g. whatsapp:+919876543210,whatsapp:+919123456780
//   5. Vercel gives you a URL like https://your-project.vercel.app
//      Your endpoint is: https://your-project.vercel.app/api/send-whatsapp
//   6. Paste that URL into the site's Settings -> "Automated WhatsApp
//      invoice" -> Webhook URL field. Done — every order now triggers
//      real WhatsApp messages automatically.
//
// COST: Twilio charges per WhatsApp message sent (a few cents each,
// depending on country) — there is no free unlimited tier for production
// sending. The sandbox itself is free for testing.

export default async function handler(req, res) {
  // Basic CORS so the browser is allowed to call this from your site
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });

  const { order, customerPhone } = req.body || {};
  if (!order) return res.status(400).json({ error: 'Missing "order" in request body' });

  const {
    TWILIO_ACCOUNT_SID,
    TWILIO_AUTH_TOKEN,
    TWILIO_WHATSAPP_FROM,
    TEAM_WHATSAPP_NUMBERS,
  } = process.env;

  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_WHATSAPP_FROM) {
    return res.status(500).json({
      error: 'Server is missing Twilio environment variables. See the setup comments at the top of this file.',
    });
  }

  const message = buildOrderMessage(order);

  const recipients = [];
  if (customerPhone) recipients.push(toWhatsAppAddress(customerPhone));
  if (TEAM_WHATSAPP_NUMBERS) {
    recipients.push(...TEAM_WHATSAPP_NUMBERS.split(',').map((n) => n.trim()).filter(Boolean));
  }

  const results = [];
  for (const to of recipients) {
    try {
      const result = await sendTwilioWhatsApp({
        accountSid: TWILIO_ACCOUNT_SID,
        authToken: TWILIO_AUTH_TOKEN,
        from: TWILIO_WHATSAPP_FROM,
        to,
        body: message,
      });
      results.push({ to, ok: true, sid: result.sid });
    } catch (err) {
      results.push({ to, ok: false, error: String(err) });
    }
  }

  return res.status(200).json({ sent: results });
}

function toWhatsAppAddress(phone) {
  let digits = String(phone).replace(/\D/g, '');
  if (digits.length === 10) digits = '91' + digits; // assume India if no country code given
  return `whatsapp:+${digits}`;
}

function buildOrderMessage(order) {
  return (
    `*3N Electronics — Order ${order.order_id}*\n\n` +
    `${order.items_list}\n\n` +
    `Subtotal: ${order.subtotal}\n` +
    `Shipping: ${order.shipping}\n` +
    `*Total: ${order.total}*\n\n` +
    `Ship to: ${order.address}\n` +
    `Phone: ${order.phone}\n` +
    `Payment ref: ${order.payment_ref}`
  );
}

async function sendTwilioWhatsApp({ accountSid, authToken, from, to, body }) {
  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
  const auth = Buffer.from(`${accountSid}:${authToken}`).toString('base64');

  const params = new URLSearchParams();
  params.append('From', from);
  params.append('To', to);
  params.append('Body', body);

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: params,
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `Twilio API error (${response.status})`);
  }
  return data;
}
